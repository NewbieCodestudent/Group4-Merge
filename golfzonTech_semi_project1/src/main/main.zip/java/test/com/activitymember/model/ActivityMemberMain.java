package test.com.activitymember.model;

import java.util.Arrays;
import java.util.List;

public class ActivityMemberMain {
	public static void main(String args[]) {
		System.out.println("Hello, ActivityMember....");
//		System.out.println(new ActivityMemberVO());
		
	} // end main
} // end class