package test.com.comment.model;

import java.util.List;

public class CommentMain {

	public static void main(String[] args) {
//		System.out.println("Hello, comment....");
//		CommentVO vo = new CommentVO();
		CommentDAO dao = new CommentDAOimpl();
		List<CommentVO> vos = dao.selectAll(5);
		System.out.println(vos);
//		BoardVO vo1 = new BoardVO();
//		vo1.setBoard_id(90);
//		vo1.setWriter("ADMIN2");
//		int result = new BoardDAOimpl().isWriter(vo1);
//		System.out.println("result: "+result);
//		CommentVO vo2 = new CommentVO();
//		vo2.setComment_id(80);
//		vo2.setCommenter("admin1");
//		result = new CommentDAOimpl().isCommenter(vo2);
//		System.out.println("result: "+result);
	} // end main
} // end class